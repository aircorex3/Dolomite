# Dolomite External

একটি রিপো, দুইটি প্রজেক্ট:

```
Dolomite/
├── .github/workflows/      ← GitHub Actions (সব workflow এখানেই)
│   ├── build-ipa.yml       ← iOS বানায় (macOS runner)
│   ├── deploy-worker.yml   ← সার্ভার → Cloudflare Worker
│   ├── deploy-render.yml   ← সার্ভার → Render
│   └── keep-alive.yml      ← Render ঘুমিয়ে না পড়ে রাখে
│
├── ios/                    ← Dolomite External iOS অ্যাপ
│   ├── ThreeOneOSFive/     ← Swift + ObjC সোর্স
│   ├── ThreeOneOSFive.xcodeproj/
│   ├── checks/native/      ← build-এর আগে চলা টেস্ট
│   ├── DolomiteLicensing.xcconfig   ← সার্ভার ঠিকানা + পাবলিক কী
│   ├── brand/              ← লোগোর মূল ফাইল
│   ├── tools/              ← অ্যাসেট জেনারেটর
│   ├── LICENSE
│   └── README.md
│
└── server/                 ← লাইসেন্স সার্ভার + ড্যাশবোর্ড
    ├── server.js           ← Node HTTP সার্ভার (zero dependency)
    ├── lib/                ← ক্রিপ্টো, লাইসেন্স API, admin API
    ├── public/             ← ড্যাশবোর্ড UI
    ├── worker/             ← Cloudflare Worker (একই কোড, আলাদা runtime)
    ├── test/               ← প্রোটোকল টেস্ট
    ├── package.json
    ├── render.yaml
    ├── HOSTING.md          ← বাংলায় হোস্টিং গাইড
    └── README.md
```

> **Workflow ফাইল অবশ্যই রিপোর রুটের `.github/workflows/`-এ থাকতে হবে** —
> GitHub অন্য কোথাও workflow খুঁজে না। তাই `ios/.github/` আর
> `server/.github/` ফোল্ডার নেই।

### জিপ থেকেও চলে

রিপোতে শুধু zip রাখলেও চলবে — workflow নিজেই zip খুলে প্রজেক্ট বসিয়ে নেয়:

| রিপোতে যদি থাকে | workflow যা করবে |
|---|---|
| `ios/` ফোল্ডার | সেটাই ব্যবহার করবে |
| `Dolomite-monorepo.zip` | `ios/` আর `server/` দুটোই খুলে বসাবে |
| `Dolomite-External-iOS.zip` | `ios/` খুলে বসাবে |
| `dolomite-dashboard.zip` | `server/` খুলে বসাবে |

তাই হাতে ১৩০টা ফাইল আপলোড না করে শুধু zip + ৪টা yml রাখলেই চলে।
কোনোটাই না থাকলে workflow স্পষ্ট মেসেজ দেখিয়ে বলে কী নেই।

---

## GitHub-এ push করার নিয়ম

```bash
cd Dolomite
git init
git add -A
git commit -m "Dolomite External"
git branch -M main
git remote add origin https://github.com/<তোমার-নাম>/Dolomite.git
git push -u origin main
```

প্রথমবার push করার পর Actions ট্যাবে চারটা workflow দেখা যাবে।

---

## Workflow কী করে

| Workflow | ট্রিগার | কাজ |
|---|---|---|
| **build-ipa.yml** | `main` push (অ্যাপ ফাইল বদলালে), `v*` ট্যাগ, ম্যানুয়াল | macOS-এ unsigned IPA বানায় → artifact; ট্যাগ হলে GitHub Release |
| **deploy-worker.yml** | `main` push (`server/` বদলালে), ম্যানুয়াল | টেস্ট করে Cloudflare Worker ডিপ্লয় + লাইভ স্মোক টেস্ট |
| **deploy-render.yml** | `main` push (`server/` বদলালে), ম্যানুয়াল | টেস্ট করে Render deploy hook ট্রিগার |
| **keep-alive.yml** | প্রতি ১০ মিনিটে (cron) | Render-কে জাগায় রাখে |

---

## সেক্রেট ও ভ্যারিয়েবল

রিপোর **Settings → Secrets and variables → Actions**:

### Secrets (লুকানো)
| নাম | কোন workflow | মান |
|---|---|---|
| `CLOUDFLARE_API_TOKEN` | deploy-worker | Cloudflare → My Profile → API Tokens → "Edit Cloudflare Workers" |
| `CLOUDFLARE_ACCOUNT_ID` | deploy-worker | Cloudflare ড্যাশবোর্ডের Account ID |
| `RENDER_DEPLOY_HOOK` | deploy-render | Render → Settings → Deploys → Deploy Hook URL |

### Variables (পড়া যায়)
| নাম | কোন workflow | মান |
|---|---|---|
| `WORKER_URL` | deploy-worker | `https://dolomite-external.<subdomain>.workers.dev` |
| `RENDER_URL` | deploy-render | Render-এর service URL |
| `SERVER_URL` | keep-alive | সার্ভারের URL (Worker হলে `WORKER_URL`-ই) |

### Dashboard পাসওয়ার্ড
- **Node/Render:** env `ADMIN_PASSWORD` সেট করো
- **Cloudflare Worker:** `cd server/worker && npx wrangler secret put ADMIN_PASSWORD`

---

## অ্যাপকে সার্ভারের সাথে যুক্ত করা

1. সার্ভার ডিপ্লয় করো (Worker বা Render)
2. ড্যাশবোর্ড খোলো → **Configuration** পেজ
3. `.xcconfig` ব্লক কপি করো → `ios/DolomiteLicensing.xcconfig`-এ বসাও
4. `ios/` বদলে push করো → নতুন IPA বানাবে

বিস্তারিত: **[server/HOSTING.md](server/HOSTING.md)**

---

## লোকালে চালানো

```bash
# সার্ভার
cd server
node server.js            # http://localhost:3000/dashboard
npm test                  # ২৮টি চেক

# ডেমো ডেটা
npm run seed

# Cloudflare Worker লোকালে
npm run dev:worker
```

---

## লাইসেন্স

GPL-3.0 — বিস্তারিত `ios/LICENSE` ও `ios/THIRD_PARTY_NOTICES.md`-এ।
