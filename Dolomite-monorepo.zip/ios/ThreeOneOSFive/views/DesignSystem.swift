import SwiftUI
import UIKit

enum AppTheme {
    static let accentStorageKey = "dolomiteAccentHex"
    static let streamerModeStorageKey = "dolomiteStreamerMode"
    static let appearanceStorageKey = "dolomiteAppearance"
    static let defaultAccentHex = "#2F80FF"
    static let defaultAppearance = "dark"

    static var accent: Color {
        Color(hex: UserDefaults.standard.string(forKey: accentStorageKey) ?? defaultAccentHex)
    }

    static var accentDeep: Color {
        Color(hex: UserDefaults.standard.string(forKey: accentStorageKey) ?? defaultAccentHex).opacity(0.72)
    }

    static var accentGradient: LinearGradient {
        LinearGradient(
            colors: [accent, accentDeep],
            startPoint: .leading,
            endPoint: .trailing
        )
    }

    /// Colour stops of the chrome gradient. A gradient's colour list only
    /// accepts `Color` values, so this is what other gradients must embed.
    static var chromeStops: [Color] {
        [
            Color(red: 0.99, green: 1.00, blue: 1.00),
            Color(red: 0.80, green: 0.89, blue: 1.00),
            Color(red: 0.55, green: 0.71, blue: 0.99),
            Color(red: 0.86, green: 0.93, blue: 1.00)
        ]
    }

    /// Polished silver used for brand wordmarks and hero surfaces.
    static var chromeGradient: LinearGradient {
        LinearGradient(
            colors: chromeStops,
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    /// Deep sapphire surface used by the hero banner.
    static var heroGradient: LinearGradient {
        LinearGradient(
            colors: [
                Color(red: 0.10, green: 0.24, blue: 0.60),
                Color(red: 0.05, green: 0.12, blue: 0.36),
                Color(red: 0.01, green: 0.03, blue: 0.10)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    static var isLightMode: Bool {
        UserDefaults.standard.string(forKey: appearanceStorageKey) == "light"
    }

    static var pageBackground: Color {
        isLightMode
            ? Color(red: 0.945, green: 0.958, blue: 0.980)
            : Color(red: 0.024, green: 0.035, blue: 0.075)
    }

    static var consoleBackground: Color {
        isLightMode ? Color.black.opacity(0.045) : Color.white.opacity(0.055)
    }

    static var card: Color {
        isLightMode
            ? Color.white.opacity(0.86)
            : Color(red: 0.055, green: 0.082, blue: 0.152).opacity(0.72)
    }

    /// Sapphire-tinted border so cards read as cut crystal instead of flat grey.
    static var cardBorder: Color {
        isLightMode
            ? Color(red: 0.18, green: 0.38, blue: 0.78).opacity(0.16)
            : Color(red: 0.40, green: 0.62, blue: 1.00).opacity(0.22)
    }

    static var cardSelected: Color { accent }
    static var primaryText: Color {
        isLightMode ? Color(red: 0.04, green: 0.07, blue: 0.15) : .white
    }
    static var secondaryText: Color {
        isLightMode
            ? Color(red: 0.29, green: 0.36, blue: 0.50)
            : Color(red: 0.63, green: 0.71, blue: 0.85)
    }
    static var tertiaryText: Color {
        isLightMode
            ? Color(red: 0.47, green: 0.53, blue: 0.66)
            : Color(red: 0.41, green: 0.49, blue: 0.64)
    }
    static var hairline: Color {
        isLightMode
            ? Color(red: 0.18, green: 0.38, blue: 0.78).opacity(0.13)
            : Color(red: 0.40, green: 0.62, blue: 1.00).opacity(0.13)
    }
    static var controlFill: Color {
        isLightMode ? Color.black.opacity(0.06) : Color.white.opacity(0.07)
    }

    static let pagePadding: CGFloat = 20
    static let sectionSpacing: CGFloat = 24
    static let rowPadding: CGFloat = 16
    static let pageInset: CGFloat = 20
    static let rowIconSize: CGFloat = 17
    static let rowIconFrame: CGFloat = 28
    static let fileRowIconSize: CGFloat = 17
    static let fileRowIconFrame: CGFloat = 30
    static let fileRowHeight: CGFloat = 60
    static let appIconSize: CGFloat = 32
    static let emptyIconSize: CGFloat = 30
    static let selectionIconSize: CGFloat = 18
    static let contentCardCornerRadius: CGFloat = 16
    static let contentCardInset: CGFloat = 16
    static let contentCardPadding: CGFloat = 16
    static let crystalCornerRadius: CGFloat = 22
}


/// Slowly drifting crystal shards over a deep sapphire glow.
struct CrystalFieldBackground: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { timeline in
            Canvas { context, size in
                let time = reduceMotion ? 0 : timeline.date.timeIntervalSinceReferenceDate

                // ambient glow behind the content
                let glowRect = CGRect(
                    x: size.width * 0.5 - size.width * 0.95,
                    y: -size.height * 0.25,
                    width: size.width * 1.9,
                    height: size.height * 1.25
                )
                context.fill(
                    Path(ellipseIn: glowRect),
                    with: .radialGradient(
                        Gradient(colors: [
                            (AppTheme.isLightMode ? Color.blue : Color(red: 0.22, green: 0.46, blue: 0.98)).opacity(0.22),
                            .clear
                        ]),
                        center: CGPoint(x: size.width * 0.5, y: size.height * 0.18),
                        startRadius: 0,
                        endRadius: max(size.width, size.height) * 0.72
                    )
                )

                let count = 28
                let period = size.height + 220.0
                for index in 0..<count {
                    let seed = Double(index)
                    let x = pseudoRandom(seed * 13.17) * size.width
                    let start = pseudoRandom(seed * 5.41) * period
                    let speed = 9.0 + pseudoRandom(seed * 7.31) * 24.0
                    let y = wrap(start - time * speed, period) - 110.0
                    let shard = 4.0 + pseudoRandom(seed * 3.83) * 12.0
                    let drift = sin(time * 0.45 + seed * 1.7) * 10.0
                    let tilt = sin(time * 0.35 + seed) * 0.25
                    let opacity = 0.10 + pseudoRandom(seed * 11.19) * 0.30
                    let tint = AppTheme.isLightMode
                        ? Color(red: 0.20, green: 0.42, blue: 0.92)
                        : Color(red: 0.58, green: 0.78, blue: 1.00)

                    // shard built around the origin, then rotated and moved
                    var path = Path()
                    path.move(to: CGPoint(x: 0, y: 0))
                    path.addLine(to: CGPoint(x: shard, y: shard * 0.60))
                    path.addLine(to: CGPoint(x: 0, y: shard * 1.22))
                    path.addLine(to: CGPoint(x: -shard, y: shard * 0.60))
                    path.closeSubpath()

                    let transform = CGAffineTransform(translationX: x + drift, y: y)
                        .rotated(by: tilt)
                    context.fill(path.applying(transform), with: .color(tint.opacity(opacity)))
                }
            }
            .allowsHitTesting(false)
        }
        .ignoresSafeArea()
        .accessibilityHidden(true)
    }

    private func pseudoRandom(_ value: Double) -> Double {
        let raw = sin(value * 12.9898) * 43758.5453
        return raw - floor(raw)
    }

    private func wrap(_ value: Double, _ period: Double) -> Double {
        let remainder = value.truncatingRemainder(dividingBy: period)
        return remainder < 0 ? remainder + period : remainder
    }
}

struct AppCardBorder: View {
    var body: some View {
        RoundedRectangle(
            cornerRadius: AppTheme.contentCardCornerRadius,
            style: .continuous
        )
        .strokeBorder(
            Color(uiColor: .separator).opacity(0.22),
            lineWidth: 0.5
        )
        .accessibilityHidden(true)
    }
}

struct AppRowIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var symbolSize: CGFloat = AppTheme.rowIconSize
    var frameSize: CGFloat = AppTheme.rowIconFrame

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7, style: .continuous)
                .fill(tint.opacity(0.12))
            Image(systemName: systemName)
                .font(.system(size: symbolSize, weight: .medium))
                .foregroundStyle(tint)
        }
        .frame(width: frameSize, height: frameSize)
        .accessibilityHidden(true)
    }
}

struct AppSearchField: View {
    @Binding var text: String
    let prompt: String
    let clearLabel: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)

            TextField(prompt, text: $text)
                .font(.body)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(clearLabel)
            }
        }
        .padding(.horizontal, 11)
        .frame(minHeight: 36)
        .background(
            Color(uiColor: .secondarySystemFill),
            in: RoundedRectangle(cornerRadius: 10, style: .continuous)
        )
        .padding(.horizontal, AppTheme.pageInset)
        .padding(.vertical, 8)
        .background(.bar)
    }
}

/// Brand lockup: the crystal mark plus a chrome "DOLOMITE" / "EXTERNAL" stack.
struct DolomiteTitleWordmark: View {
    var maxWidth: CGFloat = 240
    var alignment: Alignment = .center

    var body: some View {
        VStack(spacing: 6) {
            if let mark = UIImage(named: "AppLogo") {
                Image(uiImage: mark)
                    .resizable()
                    .scaledToFit()
                    .frame(width: maxWidth * 0.62, height: maxWidth * 0.62)
                    .clipShape(RoundedRectangle(cornerRadius: maxWidth * 0.14, style: .continuous))
            }
            Text("DOLOMITE")
                .font(.system(size: maxWidth * 0.155, weight: .black))
                .tracking(maxWidth * 0.012)
                .foregroundStyle(AppTheme.chromeGradient)
            Text("EXTERNAL")
                .font(.system(size: maxWidth * 0.105, weight: .heavy))
                .tracking(maxWidth * 0.062)
                .foregroundStyle(AppTheme.accentGradient)
        }
        .frame(maxWidth: maxWidth, alignment: alignment)
        .accessibilityLabel("Dolomite External. Play beyond limits.")
    }
}

/// Hero banner: a deep sapphire plate carrying the crystal mark and wordmark.
struct DolomiteHeroBanner: View {
    var height: CGFloat = 180
    var showsWordmark: Bool = true

    var body: some View {
        ZStack {
            AppTheme.heroGradient

            // soft light sweep across the plate
            GeometryReader { proxy in
                Circle()
                    .fill(
                        RadialGradient(
                            colors: [
                                AppTheme.accent.opacity(0.42),
                                .clear
                            ],
                            center: .center,
                            startRadius: 0,
                            endRadius: proxy.size.width * 0.62
                        )
                    )
                    .frame(width: proxy.size.width * 1.25)
                    .offset(x: proxy.size.width * 0.18, y: -height * 0.18)
            }

            HStack(spacing: 18) {
                if let mark = UIImage(named: "AppLogo") {
                    Image(uiImage: mark)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 92, height: 92)
                        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 22, style: .continuous)
                                .strokeBorder(AppTheme.chromeGradient, lineWidth: 1)
                        }
                        .shadow(color: AppTheme.accent.opacity(0.45), radius: 16, y: 6)
                }

                if showsWordmark {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("DOLOMITE")
                            .font(.system(size: 26, weight: .black))
                            .tracking(1.2)
                            .foregroundStyle(AppTheme.chromeGradient)
                        Text("EXTERNAL")
                            .font(.system(size: 15, weight: .heavy))
                            .tracking(5.0)
                            .foregroundStyle(Color.white.opacity(0.82))
                    }
                    Spacer(minLength: 0)
                }
            }
            .padding(.horizontal, 22)
        }
        .frame(maxWidth: .infinity)
        .frame(height: height)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(AppTheme.cardBorder, lineWidth: 0.8)
        }
        .accessibilityLabel("Dolomite External banner")
    }
}

struct AppLogo: View {
    var size: CGFloat = 44

    var body: some View {
        Group {
            if let icon = UIImage(named: "AppLogo")
                ?? UIImage(named: "AppIcon")
                ?? UIImage(named: "AppIcon60x60") {
                Image(uiImage: icon)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "diamond.fill")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(AppTheme.accentGradient)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: size * 0.22, style: .continuous)
                .strokeBorder(AppTheme.cardBorder, lineWidth: 0.6)
        }
        .accessibilityHidden(true)
    }
}

enum DolomiteGame: String, CaseIterable, Identifiable, Hashable {
    case freeFire
    case freeFireMax

    var id: String { rawValue }

    var slug: String {
        switch self {
        case .freeFire: return "free-fire"
        case .freeFireMax: return "free-fire-max"
        }
    }

    var title: String {
        switch self {
        case .freeFire: return "Free Fire"
        case .freeFireMax: return "Free Fire MAX"
        }
    }

    var subtitle: String {
        switch self {
        case .freeFire: return "Unlock your potential"
        case .freeFireMax: return "Maximize your experience"
        }
    }

    var eyebrow: String {
        title.uppercased()
    }

    var assetName: String {
        switch self {
        case .freeFire: return "GameIconFreeFire"
        case .freeFireMax: return "GameIconFreeFireMax"
        }
    }
}

enum FunctionGlyph {
    static func symbol(icon: String?, name: String) -> String {
        if let icon, let mapped = symbols[icon] {
            return mapped
        }
        let hay = name.lowercased()
        if hay.contains("aim") { return "scope" }
        if hay.contains("esp") || hay.contains("vision") { return "eye.fill" }
        if hay.contains("recoil") { return "line.3.horizontal" }
        if hay.contains("spread") { return "plus.viewfinder" }
        if hay.contains("reload") || hay.contains("bolt") { return "bolt.fill" }
        if hay.contains("speed") || hay.contains("run") { return "figure.run" }
        if hay.contains("ban") || hay.contains("shield") { return "shield.fill" }
        if hay.contains("shake") || hay.contains("iphone") { return "iphone" }
        return "slider.horizontal.3"
    }

    private static let symbols: [String: String] = [
        "aim": "scope",
        "vision": "eye.fill",
        "recoil": "line.3.horizontal",
        "spread": "plus.viewfinder",
        "reload": "bolt.fill",
        "speed": "figure.run",
        "shield": "shield.fill",
        "device": "iphone",
        "target": "target",
        "radar": "dot.radiowaves.left.and.right",
        "lock": "lock.fill",
        "flame": "flame.fill",
        "spark": "sparkles",
        "hand": "hand.raised.fill",
        "signal": "antenna.radiowaves.left.and.right",
        "slider": "slider.horizontal.3",
    ]
}

struct GameIcon: View {
    let game: DolomiteGame
    var size: CGFloat = 52

    var body: some View {
        Group {
            if let icon = UIImage(named: game.assetName) {
                Image(uiImage: icon)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "gamecontroller.fill")
                    .font(.system(size: size * 0.42, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(AppTheme.card)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
        .accessibilityHidden(true)
    }
}

struct ContentGameIcon: View {
    let game: ContentGameDescriptor
    var size: CGFloat = 52

    private var uploadedImage: UIImage? {
        guard game.icon.hasPrefix("data:image"),
              let comma = game.icon.firstIndex(of: ",") else { return nil }
        let payload = String(game.icon[game.icon.index(after: comma)...])
        guard let data = Data(base64Encoded: payload) else { return nil }
        return UIImage(data: data)
    }

    var body: some View {
        Group {
            if let uploadedImage {
                Image(uiImage: uploadedImage)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "gamecontroller.fill")
                    .font(.system(size: size * 0.42, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(AppTheme.card)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
        .accessibilityHidden(true)
    }
}

enum DolomiteTab: Int, CaseIterable, Hashable {
    case home
    case info

    var title: String {
        switch self {
        case .home: return "Function"
        case .info: return "Account"
        }
    }

    var icon: String {
        switch self {
        case .home: return "slider.horizontal.3"
        case .info: return "person.crop.circle"
        }
    }

    var selectedIcon: String {
        switch self {
        case .home: return "slider.horizontal.3"
        case .info: return "person.crop.circle.fill"
        }
    }
}

struct DolomiteCard<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        VStack(spacing: 0) {
            content
        }
        .background(
            LinearGradient(
                colors: [
                    AppTheme.card,
                    AppTheme.card.opacity(AppTheme.isLightMode ? 0.92 : 0.55)
                ],
                startPoint: .top,
                endPoint: .bottom
            ),
            in: RoundedRectangle(cornerRadius: AppTheme.crystalCornerRadius, style: .continuous)
        )
        .overlay {
            RoundedRectangle(cornerRadius: AppTheme.crystalCornerRadius, style: .continuous)
                .strokeBorder(AppTheme.cardBorder, lineWidth: 0.8)
        }
        .overlay(alignment: .top) {
            // crystal highlight along the top edge
            RoundedRectangle(cornerRadius: AppTheme.crystalCornerRadius, style: .continuous)
                .strokeBorder(
                    LinearGradient(
                        colors: AppTheme.chromeStops + [.clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    ),
                    lineWidth: 1
                )
                .opacity(AppTheme.isLightMode ? 0.35 : 0.55)
                .allowsHitTesting(false)
        }
    }
}

struct DolomiteCardDivider: View {
    var body: some View {
        Rectangle()
            .fill(AppTheme.hairline)
            .frame(height: 0.5)
            .padding(.leading, AppTheme.rowPadding)
            .accessibilityHidden(true)
    }
}

struct DolomiteInfoRow: View {
    let title: String
    let value: String

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 16) {
            Text(title)
                .foregroundStyle(AppTheme.primaryText)
            Spacer(minLength: 8)
            Text(value)
                .foregroundStyle(AppTheme.secondaryText)
                .multilineTextAlignment(.trailing)
        }
        .font(.system(size: 14))
        .padding(.horizontal, AppTheme.rowPadding)
        .padding(.vertical, 10)
        .frame(minHeight: 42)
        .accessibilityElement(children: .combine)
    }
}

struct DolomiteProfileIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent

    var body: some View {
        ZStack {
            Circle()
                .fill(tint.opacity(0.14))
            Image(systemName: systemName)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(tint)
        }
        .frame(width: 34, height: 34)
        .accessibilityHidden(true)
    }
}

struct DolomiteProfileRow: View {
    let icon: String
    let title: String
    var subtitle: String? = nil
    var value: String? = nil
    var badge: String? = nil
    var badgeColor: Color = Color(red: 0.22, green: 0.86, blue: 0.48)

    var body: some View {
        HStack(spacing: 12) {
            DolomiteProfileIcon(systemName: icon)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(AppTheme.primaryText)
                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle)
                        .font(.system(size: 12))
                        .foregroundStyle(AppTheme.secondaryText)
                }
            }
            Spacer(minLength: 8)
            if let badge {
                Text(badge)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(badgeColor)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 5)
                    .background(badgeColor.opacity(0.16), in: Capsule())
            } else if let value {
                Text(value)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(AppTheme.secondaryText)
                    .multilineTextAlignment(.trailing)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .frame(minHeight: 56)
        .accessibilityElement(children: .combine)
    }
}

struct DolomiteProfileCard<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        VStack(spacing: 0) {
            content
        }
        .background(
            Color.white.opacity(0.06),
            in: RoundedRectangle(cornerRadius: 24, style: .continuous)
        )
    }
}

struct DolomiteSectionHeader: View {
    let title: String

    var body: some View {
        Text(title.uppercased())
            .font(.system(size: 11, weight: .semibold))
            .tracking(0.7)
            .foregroundStyle(AppTheme.secondaryText)
            .padding(.horizontal, 4)
    }
}

struct DolomiteLiquidTabBar: View {
    @Binding var selection: DolomiteTab
    @Environment(\.appLanguage) private var language
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Namespace private var selectedTab

    var body: some View {
        HStack(spacing: 0) {
            ForEach(DolomiteTab.allCases, id: \.self) { tab in
                tabButton(tab)
            }
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 6)
        .frame(height: 62)
        .frame(maxWidth: 360)
        .background { glassCapsule }
        .clipShape(Capsule())
        .shadow(color: .black.opacity(0.6), radius: 20, y: 10)
        .frame(maxWidth: .infinity)
    }

    private var glassCapsule: some View {
        Capsule()
            .fill(AppTheme.pageBackground.opacity(0.95))
            .overlay {
                Capsule()
                    .strokeBorder(AppTheme.cardBorder, lineWidth: 0.8)
            }
            .overlay {
                Capsule()
                    .strokeBorder(
                        LinearGradient(
                            colors: AppTheme.chromeStops + [.clear],
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        lineWidth: 1
                    )
                    .opacity(0.30)
                    .allowsHitTesting(false)
            }
    }

    private func tabButton(_ tab: DolomiteTab) -> some View {
        let selected = selection == tab
        return Button {
            guard selection != tab else { return }
            withAnimation(
                reduceMotion
                    ? .easeOut(duration: 0.15)
                    : .spring(response: 0.36, dampingFraction: 0.86)
            ) {
                selection = tab
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: selected ? tab.selectedIcon : tab.icon)
                    .font(.system(size: 14, weight: .semibold))
                    .symbolRenderingMode(.monochrome)
                    .frame(width: 18, height: 18)
                Text(language.text(tab == .home ? "common.functions" : "tab.account"))
                    .font(.system(size: 12, weight: .bold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
            .foregroundStyle(selected ? Color.white : AppTheme.secondaryText)
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background {
                if selected {
                    Capsule()
                        .fill(AppTheme.accentGradient)
                        .overlay {
                            Capsule()
                                .strokeBorder(AppTheme.chromeGradient, lineWidth: 0.8)
                                .opacity(0.55)
                        }
                        .shadow(color: AppTheme.accent.opacity(0.45), radius: 10, y: 3)
                        .matchedGeometryEffect(id: "selected-tab", in: selectedTab)
                }
            }
            .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity)
        .accessibilityLabel(language.text(tab == .home ? "common.functions" : "tab.account"))
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}

extension Color {
    init(hex: String) {
        let normalized = Color.normalizedHex(hex) ?? AppTheme.defaultAccentHex
        var number: UInt64 = 0
        Scanner(string: String(normalized.dropFirst())).scanHexInt64(&number)
        let red = Double((number >> 16) & 0xFF) / 255.0
        let green = Double((number >> 8) & 0xFF) / 255.0
        let blue = Double(number & 0xFF) / 255.0
        self.init(red: red, green: green, blue: blue)
    }

    static func normalizedHex(_ value: String) -> String? {
        var text = value.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if text.hasPrefix("#") { text.removeFirst() }
        guard text.count == 6,
              text.allSatisfy({ "0123456789ABCDEF".contains($0) }) else { return nil }
        return "#\(text)"
    }

    static func isAllowedAccentHex(_ value: String) -> Bool {
        guard let normalized = normalizedHex(value) else { return false }
        var number: UInt64 = 0
        Scanner(string: String(normalized.dropFirst())).scanHexInt64(&number)
        let r = Double((number >> 16) & 0xFF)
        let g = Double((number >> 8) & 0xFF)
        let b = Double(number & 0xFF)
        let luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0
        return luminance > 0.08
    }
}

struct StreamerPrivacyOverlay: View {
    @Environment(\.appLanguage) private var language

    var body: some View {
        ZStack {
            AppTheme.pageBackground.ignoresSafeArea()
            CrystalFieldBackground()
            VStack(spacing: 16) {
                Image(systemName: "iphone.gen3")
                    .font(.system(size: 42, weight: .semibold))
                    .foregroundStyle(AppTheme.accent)
                Text(language.text("license.about_title"))
                    .font(.system(size: 27, weight: .bold))
                    .foregroundStyle(AppTheme.primaryText)
                Text(language.text("license.about_description"))
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(AppTheme.secondaryText)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: 360)
                Text(language.text("license.streamer_mode"))
                    .font(.system(size: 12, weight: .bold))
                    .tracking(1.2)
                    .foregroundStyle(AppTheme.accent)
            }
            .padding(28)
            .frame(maxWidth: 430)
        }
        .accessibilityHidden(true)
    }
}
