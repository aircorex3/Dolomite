#!/usr/bin/env python3
"""Build the Dolomite External app assets from the supplied logo artwork.

Outputs
    AppIcon-1024.png            1024x1024  sapphire gradient + crystal mark
    AppLogo.jpeg               1024x1024  sapphire gradient + crystal mark
    TitleWordmark.png          1200x250   transparent "Dolomite" wordmark
    Banner.jpg                 1024x410   gradient banner + wordmark
"""

from __future__ import annotations

import os
import pathlib

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

SRC = pathlib.Path(
    os.environ.get("SOURCE_IMAGE",
        pathlib.Path(__file__).resolve().parent.parent / "brand" / "dolomite-logo.jpg"
    )
)
ASSETS = pathlib.Path(__file__).resolve().parent.parent / "ThreeOneOSFive" / "Assets.xcassets"
WORK = pathlib.Path(__file__).resolve().parent.parent / "build" / "assets"
WORK.mkdir(exist_ok=True, parents=True)

MARK_BOX = (30, 118, 1225, 752)     # crystal D + orbit ring
WORD_BOX = (92, 746, 1218, 960)     # "Dolomite" wordmark


def cut_white(image: Image.Image, threshold: int = 44) -> Image.Image:
    """Remove the white backdrop, keeping the artwork's own white fill."""
    rgb = image.convert("RGB")
    w, h = rgb.size
    work = rgb.copy()
    px = work.load()

    seeds: list[tuple[int, int]] = []
    for x in range(w):
        for y in (0, 1, 2, h - 1, h - 2, h - 3):
            r, g, b = px[x, y]
            if r > 230 and g > 230 and b > 230:
                seeds.append((x, y))
                break
    for y in range(h):
        for x in (0, 1, 2, w - 1, w - 2, w - 3):
            r, g, b = px[x, y]
            if r > 230 and g > 230 and b > 230:
                seeds.append((x, y))
                break

    for seed in seeds:
        ImageDraw.floodfill(work, seed, (255, 0, 255), thresh=threshold)

    arr = np.asarray(work)
    removed = (arr[:, :, 0] == 255) & (arr[:, :, 1] == 0) & (arr[:, :, 2] == 255)

    base = np.asarray(rgb)
    out = np.dstack([base, np.full((h, w), 255, dtype=np.uint8)])
    out[removed, 3] = 0

    # 1px feather on the cut edge
    alpha = np.asarray(Image.fromarray(out[:, :, 3]).filter(ImageFilter.GaussianBlur(0.9)))
    out[:, :, 3] = alpha
    out[removed & (alpha < 255), 3] = np.minimum(out[removed & (alpha < 255), 3], alpha[removed & (alpha < 255)])
    return Image.fromarray(out, "RGBA")


def drop_frame_artifacts(rgba: Image.Image) -> Image.Image:
    """Remove the source image's decorative corner streaks and the wordmark tail."""
    from collections import deque

    arr = np.asarray(rgba).copy()
    alpha = arr[:, :, 3]
    mask = alpha > 32
    h, w = mask.shape
    label = np.zeros((h, w), dtype=np.int32)
    comps: list[tuple[int, int, int, int, int, int]] = []
    cid = 0
    for y in range(h):
        for x in range(w):
            if mask[y, x] and label[y, x] == 0:
                cid += 1
                queue = deque([(y, x)])
                label[y, x] = cid
                x0 = x1 = x
                y0 = y1 = y
                count = 0
                while queue:
                    cy, cx = queue.popleft()
                    count += 1
                    x0, x1 = min(x0, cx), max(x1, cx)
                    y0, y1 = min(y0, cy), max(y1, cy)
                    for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        ny, nx = cy + dy, cx + dx
                        if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] and label[ny, nx] == 0:
                            label[ny, nx] = cid
                            queue.append((ny, nx))
                comps.append((count, x0, y0, x1, y1, cid))

    comps.sort(reverse=True)
    main = comps[0][5]
    removed_mask = np.zeros((h, w), dtype=np.uint8)
    for count, x0, y0, x1, y1, comp_id in comps[1:]:
        if count < 20000:
            region = label == comp_id
            removed_mask[region] = 255
            alpha[region] = 0

    # dilate the removal so anti-aliased edges of the streaks disappear too
    if removed_mask.any():
        grown = Image.fromarray(removed_mask).filter(ImageFilter.MaxFilter(9))
        grown_arr = np.asarray(grown)
        alpha[grown_arr > 0] = 0

    # the ring's lower-left tail is a wordmark connector; drop it from the mark
    alpha[540:634, 0:268] = 0
    arr[:, :, 3] = alpha
    return Image.fromarray(arr, "RGBA")


def sapphire_gradient(size: tuple[int, int], seed: int = 11) -> Image.Image:
    w, h = size
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cx, cy = w * 0.5, h * 0.44
    d = np.sqrt(((xx - cx) / w) ** 2 + ((yy - cy) / h) ** 2)
    t = np.clip(d * 1.5, 0, 1)
    top = np.array([20, 58, 148], dtype=np.float32)
    bottom = np.array([2, 7, 26], dtype=np.float32)
    base = top[None, None, :] * (1 - t[..., None]) + bottom[None, None, :] * t[..., None]

    rng = np.random.default_rng(seed)
    streak = np.zeros((h, w), dtype=np.float32)
    for _ in range(16):
        angle = rng.uniform(-0.95, -0.22)
        offset = rng.uniform(-0.25, 1.25)
        thickness = rng.uniform(0.010, 0.050)
        v = np.sin(angle) * (xx / w) - np.cos(angle) * (yy / h) + offset
        streak += np.exp(-((v / thickness) ** 2)) * rng.uniform(0.05, 0.20)
    streak = np.clip(streak, 0, 1)
    base += streak[..., None] * np.array([70, 145, 255], dtype=np.float32)

    glow = np.exp(-(((xx - cx) / (w * 0.40)) ** 2 + ((yy - cy) / (h * 0.32)) ** 2))
    base += glow[..., None] * np.array([26, 82, 190], dtype=np.float32)
    return Image.fromarray(np.clip(base, 0, 255).astype(np.uint8), "RGB")


def place_mark(canvas: Image.Image, mark: Image.Image, box: tuple[int, int, int, int]) -> None:
    """Paste the mark into `box` of `canvas`, preserving aspect ratio."""
    x0, y0, x1, y1 = box
    tw, th = x1 - x0, y1 - y0
    scale = min(tw / mark.width, th / mark.height)
    size = (max(1, int(mark.width * scale)), max(1, int(mark.height * scale)))
    resized = mark.resize(size, Image.LANCZOS)
    px = x0 + (tw - size[0]) // 2
    py = y0 + (th - size[1]) // 2
    canvas.alpha_composite(resized, (px, py))


def main() -> None:
    if not SRC.exists():
        raise SystemExit(f"logo not found: {SRC}\nset SOURCE_IMAGE=<file>")

    src = Image.open(SRC).convert("RGB")

    mark = drop_frame_artifacts(cut_white(src.crop(MARK_BOX)))
    mark.save(WORK / "mark.png")
    print("mark:", mark.size)

    # ---------------------------------------------------------------- icon
    icon = sapphire_gradient((1024, 1024)).convert("RGBA")
    place_mark(icon, mark, (74, 96, 950, 928))
    icon.convert("RGB").save(
        ASSETS / "AppIcon.appiconset" / "AppIcon-1024.png", optimize=True
    )

    # ---------------------------------------------------------------- logo
    logo = sapphire_gradient((1024, 1024)).convert("RGBA")
    place_mark(logo, mark, (96, 110, 928, 900))
    logo.convert("RGB").save(
        ASSETS / "AppLogo.imageset" / "AppLogo.jpeg", quality=92, optimize=True
    )

    # The wordmark is rendered in SwiftUI (DolomiteTitleWordmark), so only the
    # square mark assets are produced here.
    print("icon + logo written")


if __name__ == "__main__":
    main()
