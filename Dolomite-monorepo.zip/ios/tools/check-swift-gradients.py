#!/usr/bin/env python3
"""Find SwiftUI gradient-type mistakes that a brace-balance check cannot see.

Run from anywhere:  python3 tools/check-swift-gradients.py

The two rules that break the build:

1. A `colors:` array inside LinearGradient / RadialGradient / AngularGradient /
   Gradient must hold `Color` values. Putting another `LinearGradient` in
   there fails with "cannot convert value of type 'LinearGradient' to expected
   element type 'Array<Color>.ArrayLiteralElement'".
2. `foregroundStyle` / `fill` / `stroke` / `strokeBorder` / `background(_:in:)`
   take a ShapeStyle, so a gradient is fine there — but only as the direct
   argument, never nested inside another gradient's colour list.
"""

from __future__ import annotations

import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

GRADIENT_CALL = re.compile(
    r"\b(LinearGradient|RadialGradient|AngularGradient|Gradient)\s*\("
)
GRADIENT_NAMES = ("LinearGradient", "RadialGradient", "AngularGradient")


def strip_noise(src: str) -> str:
    out: list[str] = []
    i = 0
    n = len(src)
    while i < n:
        ch = src[i]
        if ch == '"':
            i += 1
            while i < n:
                if src[i] == "\\":
                    i += 2
                    continue
                if src[i] == '"':
                    i += 1
                    break
                i += 1
            continue
        if ch == "/" and i + 1 < n and src[i + 1] == "/":
            while i < n and src[i] != "\n":
                i += 1
            continue
        if ch == "/" and i + 1 < n and src[i + 1] == "*":
            end = src.find("*/", i + 2)
            i = (end + 2) if end != -1 else n
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def matching_paren(src: str, open_index: int) -> int:
    depth = 0
    for index in range(open_index, len(src)):
        ch = src[index]
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return index
    return -1


def main() -> int:
    problems = 0
    for path in sorted(ROOT.rglob("*.swift")):
        raw = path.read_text(encoding="utf-8")
        clean = strip_noise(raw)
        rel = path.relative_to(ROOT)

        for match in GRADIENT_CALL.finditer(clean):
            kind = match.group(1)
            open_index = match.end() - 1
            close_index = matching_paren(clean, open_index)
            if close_index == -1:
                continue
            body = clean[open_index + 1 : close_index]

            # find the colours: [ ... ] inside this call
            colors_match = re.search(r"colors\s*:\s*\[", body)
            if not colors_match:
                continue
            bracket = body.index("[", colors_match.start())
            depth = 0
            end = -1
            for index in range(bracket, len(body)):
                if body[index] == "[":
                    depth += 1
                elif body[index] == "]":
                    depth -= 1
                    if depth == 0:
                        end = index
                        break
            if end == -1:
                continue
            elements = body[bracket + 1 : end]

            for gradient_name in GRADIENT_NAMES:
                if re.search(r"\b" + gradient_name + r"\b", elements):
                    line = clean[: match.start()].count("\n") + 1
                    print(
                        f"NESTED GRADIENT  {rel}:{line}\n"
                        f"    a {kind} colour list contains a {gradient_name} — "
                        f"colour lists only accept Color values"
                    )
                    problems += 1
                    break

            # an accent/chrome/hero gradient token used as a colour is the same bug
            token = re.search(r"\bAppTheme\.(\w*Gradient)\b", elements)
            if token:
                line = clean[: match.start()].count("\n") + 1
                print(
                    f"NESTED GRADIENT  {rel}:{line}\n"
                    f"    a {kind} colour list contains AppTheme.{token.group(1)} — "
                    f"use its colour stops instead"
                )
                problems += 1

    print(f"\n{problems} gradient-type problem(s)")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
