/**
 * Dolomite External — licence server & key dashboard
 *
 * Zero-dependency Node.js server that provides two surfaces:
 *
 *   1. The licence API the iOS app talks to
 *      (/api/v1/...) — encrypted request/response envelopes, device proofs.
 *   2. The admin dashboard
 *      (/dashboard)  — keys, devices, packages, API reference, configuration.
 *
 * Run:  node server.js         (PORT, DATA_DIR, ADMIN_PASSWORD)
 */

'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');

const { FileStore } = require('./lib/file-store');
const { KeyRing } = require('./lib/keyring');
const { handleLicenseRequest } = require('./lib/license-api');
const { handleAdminRequest, requireSession } = require('./lib/admin-api');

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const PUBLIC_DIR = path.join(ROOT, 'public');

const store = new FileStore(DATA_DIR);
const keyRing = new KeyRing(store);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

function sendJSON(res, status, payload, extraHeaders = {}) {
  const body = Buffer.from(JSON.stringify(payload, null, 2));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
    ...extraHeaders,
  });
  res.end(body);
}

function sendText(res, status, text) {
  const body = Buffer.from(text);
  res.writeHead(status, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Content-Length': body.length,
  });
  res.end(body);
}

/** Serve a file from public/ with a path-traversal guard. */
function serveStatic(res, urlPath) {
  const relative = urlPath === '/' ? 'index.html' : urlPath.replace(/^\/+/, '');
  const target = path.resolve(PUBLIC_DIR, relative);
  if (!target.startsWith(PUBLIC_DIR + path.sep) && target !== PUBLIC_DIR) {
    sendText(res, 403, 'Forbidden');
    return;
  }
  fs.readFile(target, (error, data) => {
    if (error) {
      sendText(res, 404, 'Not found');
      return;
    }
    const ext = path.extname(target).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': data.length,
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300',
    });
    res.end(data);
  });
}

function readBody(req, limit = 4 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = decodeURIComponent(url.pathname);

  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');

  // CORS for the licence API so a browser-based tooling can talk to it
  if (pathname.startsWith('/api/v1/')) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Dolomite-Installation-ID, X-Dolomite-Timestamp, X-Dolomite-Nonce, X-Dolomite-Proof, x-dolomite-k, x-dolomite-product');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }
  }

  try {
    // ---------------------------------------------------------- licence API
    if (pathname.startsWith('/api/v1/')) {
      const body = req.method === 'GET' || req.method === 'HEAD'
        ? Buffer.alloc(0)
        : await readBody(req);
      const result = await handleLicenseRequest({
        method: req.method,
        pathname,
        query: url.searchParams,
        headers: req.headers,
        body,
        store,
        keyRing,
      });
      if (result.raw) {
        res.writeHead(result.status, {
          'Content-Type': result.contentType || 'application/octet-stream',
          'Content-Length': result.body.length,
          ...(result.headers || {}),
        });
        res.end(result.body);
      } else {
        sendJSON(res, result.status, result.payload, result.headers || {});
      }
      return;
    }

    // ------------------------------------------------------------- admin API
    if (pathname.startsWith('/admin/api/')) {
      const body = req.method === 'GET' || req.method === 'HEAD'
        ? Buffer.alloc(0)
        : await readBody(req);
      const result = await handleAdminRequest({
        method: req.method,
        pathname: pathname.slice('/admin/api'.length),
        query: url.searchParams,
        headers: req.headers,
        body,
        store,
        keyRing,
      });
      sendJSON(res, result.status, result.payload, result.headers || {});
      return;
    }

    // ------------------------------------------------------------ dashboard
    if (pathname === '/dashboard' || pathname === '/dashboard/') {
      serveStatic(res, '/index.html');
      return;
    }
    if (pathname === '/favicon.ico') {
      serveStatic(res, '/img/favicon.svg');
      return;
    }
    if (pathname === '/health') {
      sendJSON(res, 200, {
        ok: true,
        service: 'dolomite-external',
        time: new Date().toISOString(),
      });
      return;
    }

    if (req.method === 'GET' || req.method === 'HEAD') {
      serveStatic(res, pathname);
      return;
    }

    sendText(res, 405, 'Method not allowed');
  } catch (error) {
    console.error('[error]', error && error.stack ? error.stack : error);
    if (!res.headersSent) {
      sendJSON(res, 500, { error: 'internal_error', message: String(error && error.message) });
    } else {
      res.end();
    }
  }
});

async function start() {
  await keyRing.ensure();
  server.listen(PORT, () => {
    console.log(`Dolomite External server listening on :${PORT}`);
    console.log(`  dashboard  ->  http://localhost:${PORT}/dashboard`);
    console.log(`  licence   ->  http://localhost:${PORT}/api/v1/`);
    console.log(`  data dir  ->  ${DATA_DIR}`);
    if (!process.env.ADMIN_PASSWORD) {
      console.warn('  ! ADMIN_PASSWORD is not set — the dashboard uses the default password.');
    }
  });
}

start().catch((error) => {
  console.error('failed to start:', error);
  process.exit(1);
});

module.exports = { server, store, keyRing };
