/**
 * Cloudflare Worker test.
 *
 * Runs the Worker entry point against an in-memory KV stand-in, so the
 * Worker path is verified without deploying anything.
 */

'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');

const worker = require('../worker/src/index.js');

let passed = 0;
let failed = 0;

function check(label, fn) {
  try {
    fn();
    passed += 1;
    console.log(`  ok   ${label}`);
  } catch (error) {
    failed += 1;
    console.error(`  FAIL ${label}\n       ${error.message}`);
  }
}

/** Minimal Workers KV stand-in. */
class MemoryKV {
  constructor() {
    this.data = new Map();
  }

  async get(key) {
    return this.data.has(key) ? this.data.get(key) : null;
  }

  async put(key, value) {
    this.data.set(key, value);
  }
}

const P256_SPKI_PREFIX = Buffer.from(
  '3059301306072a8648ce3d020106082a8648ce3d030107034200', 'hex'
);

function makeDeviceKeyPair() {
  return crypto.generateKeyPairSync('ec', {
    namedCurve: 'prime256v1',
    publicKeyEncoding: { type: 'spki', format: 'der' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  });
}

function sealRequest(value, rsaPublicKey) {
  const aesKey = crypto.randomBytes(32);
  const nonce = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', aesKey, nonce);
  const ciphertext = Buffer.concat([
    cipher.update(Buffer.from(JSON.stringify(value), 'utf8')),
    cipher.final(),
  ]);
  const payload = Buffer.concat([ciphertext, cipher.getAuthTag()]);
  const wrapped = crypto
    .publicEncrypt(
      {
        key: rsaPublicKey,
        padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
        oaepHash: 'sha256',
      },
      aesKey
    )
    .toString('base64');
  return Buffer.from(
    JSON.stringify({
      v: 1, k: wrapped, n: nonce.toString('base64'), p: payload.toString('base64'),
    }),
    'utf8'
  );
}

function openResponse(buffer, rsaPrivateKey) {
  const envelope = JSON.parse(buffer.toString('utf8'));
  assert.equal(envelope.v, 1);

  const message = Buffer.concat([
    Buffer.from([1]),
    Buffer.from(envelope.n, 'base64'),
    Buffer.from(envelope.p, 'base64'),
  ]);
  assert.ok(
    crypto.verify(
      'sha256',
      message,
      {
        key: rsaPrivateKey,
        padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
        saltLength: crypto.constants.RSA_PSS_SALTLEN_DIGEST,
      },
      Buffer.from(envelope.s, 'base64')
    ),
    'response signature must verify'
  );

  const aesKey = crypto.privateDecrypt(
    {
      key: rsaPrivateKey,
      padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
      oaepHash: 'sha256',
    },
    Buffer.from(envelope.k, 'base64')
  );
  const nonce = Buffer.from(envelope.n, 'base64');
  const payload = Buffer.from(envelope.p, 'base64');
  const decipher = crypto.createDecipheriv('aes-256-gcm', aesKey, nonce);
  decipher.setAuthTag(payload.subarray(payload.length - 16));
  const plain = Buffer.concat([
    decipher.update(payload.subarray(0, payload.length - 16)),
    decipher.final(),
  ]);
  return JSON.parse(plain.toString('utf8'));
}

async function main() {
  console.log('\nDolomite External — Cloudflare Worker test\n');

  const kv = new MemoryKV();
  const env = {
    DOLOMITE_KV: kv,
    ADMIN_PASSWORD: 'worker-password',
    PUBLIC_BASE_URL: 'https://dolomite.example',
  };

  const call = async (path, options = {}) => {
    const headers = { 'Content-Type': 'application/json', 'x-dolomite-product': 'dolomite', ...(options.headers || {}) };
    const body = options.raw ? options.raw : options.body ? sealRequest(options.body, rsaPublic) : undefined;
    const response = await worker.fetch(
      new Request(`https://dolomite.example${path}`, { method: options.method || 'POST', headers, body }),
      env
    );
    const buffer = Buffer.from(await response.arrayBuffer());
    let parsed = null;
    try {
      const raw = JSON.parse(buffer.toString('utf8'));
      parsed = raw && raw.v === 1 && raw.p && raw.s ? openResponse(buffer, rsaPrivate) : raw;
    } catch { /* not json */ }
    return { status: response.status, body: parsed, buffer, response };
  };

  // ------------------------------------------------------------- health
  const health = await worker.fetch(new Request('https://dolomite.example/health'), env);
  check('health responds', () => {
    assert.equal(health.status, 200);
  });

  // --------------------------------------------------------------- admin
  const badLogin = await worker.fetch(
    new Request('https://dolomite.example/admin/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: 'wrong' }),
    }),
    env
  );
  check('the worker honours ADMIN_PASSWORD', () => assert.equal(badLogin.status, 401));

  const login = await worker.fetch(
    new Request('https://dolomite.example/admin/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: 'worker-password' }),
    }),
    env
  );
  const cookie = (login.headers.get('set-cookie') || '').split(';')[0];
  check('the worker issues a session cookie', () => {
    assert.ok(cookie.startsWith('dolomite_session='));
  });

  const createKey = await worker.fetch(
    new Request('https://dolomite.example/admin/api/keys', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ label: 'Worker key', plan: 'premium', days: 30 }),
    }),
    env
  );
  const created = await createKey.json();
  check('the worker creates a licence key', () => {
    assert.equal(createKey.status, 201);
    assert.match(created.key.key, /^DOLO(-[A-Z2-9]{4}){4}$/);
  });

  // ------------------------------------------------------- key material
  const stored = JSON.parse(await kv.get('server-keys'));
  const rsaPrivate = crypto.createPrivateKey(stored.rsaPrivatePEM);
  const rsaPublic = crypto.createPublicKey(stored.rsaPublicPEM);
  check('the worker generated and stored a keypair', () => {
    assert.ok(stored.rsaPrivatePEM);
    assert.ok(stored.ed25519PrivatePEM);
  });

  // ---------------------------------------------------------- activation
  const device = makeDeviceKeyPair();
  const deviceRaw = device.publicKey.subarray(device.publicKey.length - 65);
  const installationID = crypto.randomUUID();

  const start = await call('/api/v1/activation/start', {
    body: {
      license_key: created.key.key,
      device_model: 'iPhone16,2',
      system_version: '18.7.1',
      system_build: '22H100',
      app_version: '4.0',
      app_build: '4',
      installation_id: installationID,
      device_hwid: 'hwid',
      public_key: deviceRaw.toString('base64'),
      public_key_format: 'p256-x963-base64',
    },
  });
  check('the worker runs activation/start', () => {
    assert.equal(start.status, 200);
    assert.ok(start.body.activation_id);
  });

  const proof = crypto.sign('sha256', Buffer.from(start.body.challenge, 'utf8'), {
    key: device.privateKey,
    dsaEncoding: 'der',
  });

  const status = await call('/api/v1/activation/status', {
    body: {
      activation_id: start.body.activation_id,
      poll_token: start.body.poll_token,
      installation_id: installationID,
      challenge_id: start.body.challenge_id,
      proof_signature: proof.toString('base64'),
      proof_signature_format: 'ecdsa-p256-sha256-der-base64',
    },
  });
  check('the worker completes activation and issues credentials', () => {
    assert.equal(status.status, 200);
    assert.ok(status.body.credentials.access_token);
  });

  const lease = await call('/api/v1/session/lease', {
    body: {},
    headers: { Authorization: `Bearer ${status.body.credentials.access_token}` },
  });
  check('the worker issues a lease', () => {
    assert.equal(lease.status, 200);
    assert.ok(lease.body.lease);
  });

  const manifest = await call('/api/v1/content/latest', {
    method: 'GET',
    headers: { Authorization: `Bearer ${status.body.credentials.access_token}` },
  });
  check('the worker answers the manifest route', () => {
    assert.equal(manifest.status, 200);
    assert.ok(manifest.body.absent || manifest.body.manifest_base64);
  });

  // ---------------------------------------------------------- signature
  const signed = await call('/api/v1/session/lease', {
    body: {},
    headers: { Authorization: `Bearer ${status.body.credentials.access_token}` },
  });
  check('the worker envelope verifies against the stored key', () => {
    const plain = openResponse(signed.buffer, rsaPrivate);
    assert.ok(plain.lease);
  });

  console.log(`\n${passed} passed, ${failed} failed\n`);
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
