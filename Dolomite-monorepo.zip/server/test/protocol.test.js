/**
 * End-to-end protocol test.
 *
 * Speaks to the server exactly the way the iOS client does: RSA-OAEP wrapped
 * AES-256-GCM envelopes, RSA-PSS signed responses and ECDSA P-256 device
 * proofs. If this passes, the app can talk to the server.
 */

'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');

const DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'dolomite-test-'));
const PORT = 4000 + Math.floor(Math.random() * 900);
const BASE = `http://127.0.0.1:${PORT}`;
const ADMIN_PASSWORD = 'test-password';

let passed = 0;
let failed = 0;

function check(label, fn) {
  try {
    fn();
    passed += 1;
    console.log(`  ok   ${label}`);
  } catch (error) {
    failed += 1;
    console.error(`  FAIL ${label}\n       ${error.message}`);
  }
}

// ------------------------------------------------------------ client helpers

const P256_SPKI_PREFIX = Buffer.from(
  '3059301306072a8648ce3d020106082a8648ce3d030107034200', 'hex'
);

function makeDeviceKeyPair() {
  return crypto.generateKeyPairSync('ec', {
    namedCurve: 'prime256v1',
    publicKeyEncoding: { type: 'spki', format: 'der' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  });
}

function rawPublicKey(der) {
  return der.subarray(der.length - 65);
}

function signProof(privateKey, message) {
  return crypto.sign('sha256', Buffer.from(message, 'utf8'), {
    key: privateKey,
    dsaEncoding: 'der',
  });
}

function verifyProof(publicRaw, message, signatureB64) {
  const key = crypto.createPublicKey({
    key: Buffer.concat([P256_SPKI_PREFIX, publicRaw]),
    format: 'der',
    type: 'spki',
  });
  return crypto.verify(
    'sha256',
    Buffer.from(message, 'utf8'),
    { key, dsaEncoding: 'der' },
    Buffer.from(signatureB64, 'base64')
  );
}

/** Build the request envelope the Swift client sends. */
function sealRequest(value, rsaPublicKey) {
  const aesKey = crypto.randomBytes(32);
  const nonce = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', aesKey, nonce);
  const ciphertext = Buffer.concat([
    cipher.update(Buffer.from(JSON.stringify(value), 'utf8')),
    cipher.final(),
  ]);
  const payload = Buffer.concat([ciphertext, cipher.getAuthTag()]);
  const wrapped = crypto
    .publicEncrypt(
      {
        key: rsaPublicKey,
        padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
        oaepHash: 'sha256',
      },
      aesKey
    )
    .toString('base64');
  return Buffer.from(
    JSON.stringify({
      v: 1,
      k: wrapped,
      n: nonce.toString('base64'),
      p: payload.toString('base64'),
    }),
    'utf8'
  );
}

/** Open the signed response envelope the Swift client receives. */
function openResponse(buffer, rsaPublicKey) {
  const envelope = JSON.parse(buffer.toString('utf8'));
  assert.equal(envelope.v, 1, 'envelope version');

  const message = Buffer.concat([
    Buffer.from([1]),
    Buffer.from(envelope.n, 'base64'),
    Buffer.from(envelope.p, 'base64'),
  ]);
  const verified = crypto.verify(
    'sha256',
    message,
    {
      key: rsaPublicKey,
      padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
      saltLength: crypto.constants.RSA_PSS_SALTLEN_DIGEST,
    },
    Buffer.from(envelope.s, 'base64')
  );
  assert.ok(verified, 'RSA-PSS signature must verify');

  const aesKey = crypto.privateDecrypt(
    {
      key: rsaPrivateKeyForTest,
      padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
      oaepHash: 'sha256',
    },
    Buffer.from(envelope.k, 'base64')
  );
  const nonce = Buffer.from(envelope.n, 'base64');
  const payload = Buffer.from(envelope.p, 'base64');
  const tag = payload.subarray(payload.length - 16);
  const decipher = crypto.createDecipheriv('aes-256-gcm', aesKey, nonce);
  decipher.setAuthTag(tag);
  const plain = Buffer.concat([
    decipher.update(payload.subarray(0, payload.length - 16)),
    decipher.final(),
  ]);
  return JSON.parse(plain.toString('utf8'));
}

// The test needs the server's private key to unwrap the response AES key,
// exactly like the app would use the public key it was configured with.
let rsaPrivateKeyForTest = null;
let rsaPublicKeyForTest = null;

async function call(pathname, { method = 'POST', body = null, token = null, proof = null } = {}) {
  const headers = { 'Content-Type': 'application/json', 'x-dolomite-product': 'dolomite' };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (proof) {
    headers['X-Dolomite-Installation-ID'] = proof.installationID;
    headers['X-Dolomite-Timestamp'] = String(proof.timestamp);
    headers['X-Dolomite-Nonce'] = proof.nonce;
    headers['X-Dolomite-Proof'] = proof.signature;
  }
  const payload = body === null ? undefined : sealRequest(body, rsaPublicKeyForTest);
  const response = await fetch(`${BASE}/api/v1${pathname}`, {
    method,
    headers,
    body: payload,
  });
  const raw = Buffer.from(await response.arrayBuffer());
  if (response.status === 204) return { status: response.status, raw: null };
  const text = raw.toString('utf8');
  let plain;
  try {
    plain = text.trim().startsWith('{') && text.includes('"p"')
      ? openResponse(raw, rsaPublicKeyForTest)
      : JSON.parse(text);
  } catch {
    plain = { raw: text };
  }
  return { status: response.status, body: plain, raw };
}

async function adminCall(pathname, { method = 'GET', body = null } = {}) {
  const response = await fetch(`${BASE}/admin/api${pathname}`, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const payload = await response.json().catch(() => null);
  return { status: response.status, body: payload };
}

// -------------------------------------------------------------------- suite

async function main() {
  console.log(`\nDolomite External — protocol test (port ${PORT})\n`);

  const server = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
    env: {
      ...process.env,
      PORT: String(PORT),
      DATA_DIR,
      ADMIN_PASSWORD,
      PUBLIC_BASE_URL: 'https://dolomite.test',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  server.stdout.on('data', (d) => process.env.VERBOSE && process.stdout.write(`  [srv] ${d}`));
  server.stderr.on('data', (d) => process.stderr.write(`  [srv] ${d}`));

  // wait for the port
  for (let i = 0; i < 60; i += 1) {
    try {
      await fetch(`${BASE}/health`);
      break;
    } catch {
      await new Promise((r) => setTimeout(r, 100));
    }
  }

  try {
    // ------------------------------------------------------ admin login
    console.log('admin api');
    const badLogin = await adminCall('/login', { method: 'POST', body: { password: 'nope' } });
    check('rejects a wrong password', () => assert.equal(badLogin.status, 401));

    const login = await fetch(`${BASE}/admin/api/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: ADMIN_PASSWORD }),
    });
    const cookie = (login.headers.get('set-cookie') || '').split(';')[0];
    check('issues a session cookie', () => assert.ok(cookie.startsWith('dolomite_session=')));

    const cookieHeader = { 'Content-Type': 'application/json', Cookie: cookie };
    const createRes = await fetch(`${BASE}/admin/api/keys`, {
      method: 'POST',
      headers: cookieHeader,
      body: JSON.stringify({ label: 'Test key', plan: 'premium', days: 30 }),
    });
    const created = await createRes.json();
    check('creates a licence key', () => {
      assert.equal(createRes.status, 201);
      assert.match(created.key.key, /^DOLO(-[A-Z2-9]{4}){4}$/);
    });

    const licenseKey = created.key.key;

    // --------------------------------------------- pull the server keys
    const configRes = await fetch(`${BASE}/admin/api/config`, { headers: cookieHeader });
    const config = await configRes.json();
    check('exposes the public keys', () => {
      assert.ok(config.rsaPublic.length > 300);
      assert.equal(Buffer.from(config.ed25519Public, 'base64').length, 32);
    });

    const keyFile = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'server-keys.json'), 'utf8'));
    rsaPrivateKeyForTest = crypto.createPrivateKey(keyFile.rsaPrivatePEM);
    rsaPublicKeyForTest = crypto.createPublicKey(keyFile.rsaPublicPEM);

    // ------------------------------------------------------- activation
    console.log('\nlicence api');
    const device = makeDeviceKeyPair();
    const deviceRaw = rawPublicKey(device.publicKey);
    const installationID = crypto.randomUUID();

    const start = await call('/activation/start', {
      body: {
        license_key: licenseKey,
        device_model: 'iPhone16,2',
        system_version: '18.7.1',
        system_build: '22H100',
        app_version: '4.0',
        app_build: '4',
        installation_id: installationID,
        device_hwid: 'test-hwid',
        public_key: deviceRaw.toString('base64'),
        public_key_format: 'p256-x963-base64',
      },
    });
    check('activation/start returns a challenge', () => {
      assert.equal(start.status, 200);
      assert.ok(start.body.activation_id);
      assert.ok(start.body.challenge);
    });

    const proofSignature = signProof(
      device.privateKey,
      Buffer.from(start.body.challenge, 'utf8')
    );
    check('the device proof verifies against the public key', () => {
      assert.ok(
        verifyProof(deviceRaw, start.body.challenge, proofSignature.toString('base64'))
      );
    });

    const status = await call('/activation/status', {
      body: {
        activation_id: start.body.activation_id,
        poll_token: start.body.poll_token,
        installation_id: installationID,
        challenge_id: start.body.challenge_id,
        proof_signature: proofSignature.toString('base64'),
        proof_signature_format: 'ecdsa-p256-sha256-der-base64',
      },
    });
    check('activation/status issues credentials', () => {
      assert.equal(status.status, 200);
      assert.ok(status.body.credentials.access_token);
      assert.ok(status.body.credentials.refresh_token);
      assert.equal(status.body.credentials.profile.masked_key.length > 5, true);
    });

    const accessToken = status.body.credentials.access_token;
    const refreshToken = status.body.credentials.refresh_token;

    // ------------------------------------------------------- session
    const challenge = await call('/session/challenge', {
      body: { installation_id: installationID, credential_type: 'access' },
      token: accessToken,
    });
    check('session/challenge returns a fresh challenge', () => {
      assert.equal(challenge.status, 200);
      assert.ok(challenge.body.challenge_id);
    });

    const sessionProof = signProof(
      device.privateKey,
      Buffer.from(challenge.body.challenge, 'utf8')
    );
    const validated = await call('/session/validate', {
      body: {
        installation_id: installationID,
        challenge_id: challenge.body.challenge_id,
        proof_signature: sessionProof.toString('base64'),
        proof_signature_format: 'ecdsa-p256-sha256-der-base64',
      },
      token: accessToken,
    });
    check('session/validate rotates the tokens', () => {
      assert.equal(validated.status, 200);
      assert.ok(validated.body.access_token);
      assert.notEqual(validated.body.access_token, accessToken);
    });

    const rotatedAccess = validated.body.access_token;
    const rotatedRefresh = validated.body.refresh_token;

    // ---------------------------------------------------------- lease
    const lease = await call('/session/lease', {
      body: {},
      token: rotatedAccess,
    });
    check('session/lease issues a lease', () => {
      assert.equal(lease.status, 200);
      assert.ok(lease.body.lease);
      assert.ok(lease.body.expires_at);
    });

    // --------------------------------------------------------- permit
    const permitBody = {
      request_id: crypto.randomUUID(),
      package_id: 'com.dolomite.pkg.aim',
      sha256: 'a'.repeat(64),
      action: 'apply',
      app_version: '4.0',
      app_build: '4',
    };
    const timestamp = Math.floor(Date.now() / 1000);
    const nonce = crypto.randomUUID();
    const canonical = [
      'POST',
      '/v1/session/permit',
      installationID,
      String(timestamp),
      nonce,
      'body-sha256',
      crypto.createHash('sha256').update(JSON.stringify(permitBody)).digest('hex'),
    ].join('\n');

    const permit = await call('/session/permit', {
      body: permitBody,
      token: rotatedAccess,
      proof: {
        installationID,
        timestamp,
        nonce,
        signature: signProof(device.privateKey, canonical).toString('base64'),
      },
    });
    check('session/permit returns a signed permit', () => {
      assert.equal(permit.status, 200);
      assert.ok(permit.body.permit_base64);
      const edKey = crypto.createPublicKey({
        key: Buffer.concat([
          Buffer.from('302a300506032b6570032100', 'hex'),
          Buffer.from(config.ed25519Public, 'base64'),
        ]),
        format: 'der',
        type: 'spki',
      });
      const ok = crypto.verify(
        null,
        Buffer.from(permit.body.permit_base64, 'base64'),
        edKey,
        Buffer.from(permit.body.signature, 'base64')
      );
      assert.ok(ok, 'permit signature must verify with the Ed25519 public key');
    });

    // ------------------------------------------------------- content
    const seedManifest = await fetch(`${BASE}/admin/api/manifest`, {
      method: 'PUT',
      headers: cookieHeader,
      body: JSON.stringify({
        manifest: {
          product: 'dolomite-mod-vip',
          release_id: 'rel-test-1',
          version: '1.0.0',
          name: 'Test release',
          required: false,
          packages: [],
        },
      }),
    });
    check('publishes a content manifest', () => assert.equal(seedManifest.status, 200));

    const manifest = await call('/content/latest', { method: 'GET', token: rotatedAccess });
    check('content/latest serves a signed manifest', () => {
      assert.equal(manifest.status, 200);
      assert.ok(manifest.body.manifest_base64);
      const edKey = crypto.createPublicKey({
        key: Buffer.concat([
          Buffer.from('302a300506032b6570032100', 'hex'),
          Buffer.from(config.ed25519Public, 'base64'),
        ]),
        format: 'der',
        type: 'spki',
      });
      const ok = crypto.verify(
        null,
        Buffer.from(manifest.body.manifest_base64, 'base64'),
        edKey,
        Buffer.from(manifest.body.signature, 'base64')
      );
      assert.ok(ok, 'manifest signature must verify');
    });

    // --------------------------------------------------------- notice
    const notice = await call('/dolomite/notice', { body: null });
    check('notice answers in plain JSON', () => {
      assert.equal(notice.status, 200);
      assert.ok('enabled' in notice.body);
    });

    // ------------------------------------------------- authorisation
    const noToken = await call('/session/lease', { body: {} });
    check('refuses a request without a bearer token', () => {
      assert.equal(noToken.status, 401);
    });

    const wrongKey = await call('/activation/start', {
      body: {
        license_key: 'DOLO-AAAA-BBBB-CCCC-DDDD',
        device_model: 'iPhone16,2',
        system_version: '18.7.1',
        system_build: '22H100',
        app_version: '4.0',
        app_build: '4',
        installation_id: crypto.randomUUID(),
        device_hwid: 'x',
        public_key: deviceRaw.toString('base64'),
        public_key_format: 'p256-x963-base64',
      },
    });
    check('refuses an unknown licence key', () => {
      assert.equal(wrongKey.status, 401);
    });

    // -------------------------------------------------- key lifecycle
    const revoke = await fetch(`${BASE}/admin/api/keys/${created.key.id}/revoke`, {
      method: 'POST',
      headers: cookieHeader,
    });
    check('revokes a licence', () => {
      assert.equal(revoke.status, 200);
    });

    const afterRevoke = await call('/session/lease', { body: {}, token: rotatedAccess });
    check('a revoked licence loses its session', () => {
      assert.equal(afterRevoke.status, 401);
    });
  } finally {
    server.kill();
    fs.rmSync(DATA_DIR, { recursive: true, force: true });
  }

  console.log(`\n${passed} passed, ${failed} failed\n`);
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
