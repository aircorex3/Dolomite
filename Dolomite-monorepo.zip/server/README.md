# Dolomite External — Licence Server & Dashboard

The backend for the **Dolomite External** iOS app. One process serves:

- **The licence API** the app talks to (`/api/v1/...`) — activation, sessions,
  leases, write permits and the signed content manifest.
- **The dashboard** (`/dashboard`) — every licence key, every bound device, the
  published packages, the API reference and the client configuration.

No dependencies. `node server.js` and you are live.

---

## Run it

```bash
node server.js
# dashboard  ->  http://localhost:3000/dashboard
# licence    ->  http://localhost:3000/api/v1/
```

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `3000` | HTTP port |
| `DATA_DIR` | `./data` | Where the JSON store and key material live |
| `ADMIN_PASSWORD` | `dolomite` | Dashboard login |
| `PUBLIC_BASE_URL` | placeholder | Base URL baked into the client config page |

The first boot generates an **RSA-3072** and an **Ed25519** keypair and writes
them to `data/server-keys.json`. Back that file up — the private keys live
nowhere else, and the app will refuse to talk to a server whose public keys
have drifted.

---

## The dashboard

| Page | What it holds |
| --- | --- |
| **Overview** | Active / expired / revoked counts, devices bound, activations in the last 24 h, activity feed, keys expiring within 7 days |
| **Licence keys** | Every key with its plan, status, expiry and bound device. Create, extend, unbind, revoke, restore, delete |
| **Devices** | Installation id, model, iOS version and build for every activated device |
| **Packages** | Function packs published to the app, with SHA-256 and download URL |
| **API reference** | Every endpoint with request/response bodies, the header contract and the envelope format |
| **Configuration** | The public keys, a ready-to-paste `.xcconfig` block and the login notice editor |

Keys look like `DOLO-XXXX-XXXX-XXXX-XXXX` (Crockford-ish alphabet, no I/O/0/1).

---

## Point the app at this server

Open **Configuration** in the dashboard, copy the `.xcconfig` block and paste it
over `DolomiteLicensing.xcconfig` in the app repo:

```
LICENSE_SERVER_BASE_URL = https://your-domain.example
CONTENT_MANIFEST_PUBLIC_KEY = <ed25519 raw key, base64>
RESPONSE_RSA3072_PUBLIC_KEY = <rsa spki der, base64>
```

Then rebuild the app. The build phase folds those values into
`RuntimeMaterial.generated.swift` as obfuscated bytes; nothing sensitive is
compiled in — only public material.

> The base URL may carry a path prefix. The app appends `v1/...` to it, so
> `https://host` yields `https://host/v1/session/validate` and
> `https://host/api` yields `https://host/api/v1/session/validate`. This server
> answers on both `/v1/...` and `/api/v1/...`.

---

## Protocol summary

Every endpoint except the notice uses an encrypted envelope.

**Request** (client → server)

```json
{"v":1,"k":"<rsa-oaep(aesKey)>","n":"<nonce>","p":"<ciphertext||tag>"}
```

**Response** (server → client)

```json
{"v":1,"k":"<rsa-oaep(aesKey)>","n":"<nonce>","p":"<ciphertext||tag>","s":"<rsa-pss signature>"}
```

- The AES-256 key is wrapped with **RSA-OAEP-SHA256** towards the client's
  public key; the payload is **AES-256-GCM** with a 12-byte nonce.
- The response signature is **RSA-PSS-SHA256** over `0x01 || nonce || payload`,
  so the client can prove the envelope came from the key holder.
- The device proof header is **ECDSA P-256 / SHA-256** over
  `METHOD\npath?query\ninstallation_id\ntimestamp\nnonce` — plus
  `body-sha256\n<hash>` when the body is bound.

### Endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/v1/dolomite/notice` | Login-screen announcement (plain JSON) |
| POST | `/v1/activation/start` | Begin activation, returns a device challenge |
| POST | `/v1/activation/status` | Submit the device proof, receive credentials |
| POST | `/v1/session/challenge` | Request a proof challenge |
| POST | `/v1/session/validate` | Exchange a proof for fresh credentials |
| POST | `/v1/session/refresh` | Rotate an expiring session |
| POST | `/v1/session/lease` | Short-lived operation lease |
| POST | `/v1/session/permit` | Signed permit for one write |
| GET | `/v1/content/latest` | Ed25519-signed content manifest |

### Headers

| Header | Value |
| --- | --- |
| `Authorization` | `Bearer <access token or refresh token>` |
| `X-Dolomite-Installation-ID` | The device installation UUID |
| `X-Dolomite-Timestamp` | Unix seconds, within 5 minutes of server time |
| `X-Dolomite-Nonce` | Unique per request |
| `X-Dolomite-Proof` | ECDSA P-256 signature of the canonical request |
| `x-dolomite-k` | Base64 RSA-OAEP wrapped AES key for the response |
| `x-dolomite-product` | Always `dolomite` |

---

## Data layout

```
data/
├── server-keys.json   RSA + Ed25519 key material  ← back this up
├── keys.json          licence keys
├── sessions.json      live sessions
├── challenges.json    pending device challenges
├── activations.json   in-flight activations
├── packages.json      published function packs
├── manifest.json      content manifest served to the app
├── games.json         game descriptors
├── notice.json        login notice
└── activity.json      rolling activity log
```

Every file is plain JSON, written atomically. Copy the folder to back up the
whole server.

---

## Deploy

**→ Read [HOSTING.md](HOSTING.md) for the full guide.** It covers both
VPS-free options: GitHub Actions for the IPA build, and the licence server on
Cloudflare Workers (always on, free) or Render free tier.

Quick version:

| Target | Command |
| --- | --- |
| Cloudflare Worker | `npm run deploy:worker` — or push to `main` and let `deploy-worker.yml` do it |
| Render | push to `main`, `deploy-render.yml` fires the deploy hook |
| Any Node host | `node server.js` |

`render.yaml` is included. On Render:

1. Push the repository.
2. Create a Blueprint from `render.yaml`.
3. Set `PUBLIC_BASE_URL` to the assigned domain.
4. Copy the `.xcconfig` block from the dashboard into the app repo.

The disk mount at `/var/data` keeps the key material across restarts — without
it, every deploy would generate a new keypair and invalidate the app.

---

## Tests

```bash
npm test              # both suites
npm run test:protocol # the Node server
npm run test:worker   # the Cloudflare Worker
```

`test/protocol.test.js` boots the server on an ephemeral port and walks the
full activation → session → permit → manifest flow, including envelope
decryption and signature verification.

`test/worker.test.js` runs the Worker entry point against an in-memory KV
stand-in, so the Worker path is covered without deploying anything.

Both suites pass 28 checks in total.

---

## Licence

GPL-3.0 — same terms as the app.
