/**
 * Seed demo data so the dashboard has something to show.
 *
 *   node scripts/seed.js
 *
 * Pass --force to wipe existing keys first.
 */

'use strict';

const { FileStore } = require('../lib/file-store');
const { randomKey, randomToken } = require('../lib/license-api');

const store = new FileStore(process.env.DATA_DIR || require('node:path').join(__dirname, '..', 'data'));
const force = process.argv.includes('--force');

const DEMO_KEYS = [
  { label: 'Rakib — FF Max', plan: 'premium', days: 30, bound: 'iPhone15,3', ios: '18.7.1', build: '22H100' },
  { label: 'Sadia — Free Fire', plan: 'standard', days: 7, bound: 'iPhone16,2', ios: '18.5.0', build: '22F76' },
  { label: 'Tanvir — Trial', plan: 'trial', days: 3, bound: null, ios: null, build: null },
  { label: 'Nayeem — Lifetime', plan: 'lifetime', days: 3650, bound: 'iPhone14,2', ios: '17.7.1', build: '21H219' },
  { label: 'Old customer', plan: 'standard', days: -12, bound: 'iPhone13,2', ios: '17.4.1', build: '21E236' },
];

const DEMO_PACKAGES = [
  {
    identifier: 'com.dolomite.pkg.aim',
    name: 'Aim assist',
    version: '2.4.1',
    fileName: 'aim-2.4.1.dolomite',
    sha256: '4f1c9ab30d6e57b8c2a1f0d4e8b6c7a95e3f1b2d4c6a8e0f2b4d6c8a0e2f4b6d8',
    size: 184320,
    game: 'free-fire',
    description: 'Smoothed aim and silent recoil for Free Fire.',
  },
  {
    identifier: 'com.dolomite.pkg.wallpaper',
    name: 'Dolomite wallpapers',
    version: '1.2.0',
    fileName: 'dolomite-walls-1.2.0.tendies',
    sha256: 'a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90',
    size: 5242880,
    game: 'posterboard',
    description: 'PosterBoard collection package.',
  },
];

function daysFromNow(days) {
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();
}

function main() {
  if (force) {
    store.write('keys', []);
    store.write('activity', []);
  }

  const existing = store.read('keys', []);
  if (existing.length && !force) {
    console.log(`keys.json already holds ${existing.length} keys — pass --force to replace them.`);
    return;
  }

  const keys = DEMO_KEYS.map((demo, index) => {
    const entry = {
      id: randomToken(10),
      key: randomKey(),
      label: demo.label,
      plan: demo.plan,
      status: 'active',
      notes: '',
      createdAt: new Date(Date.now() - (index + 1) * 36 * 3600 * 1000).toISOString(),
      expiresAt: daysFromNow(demo.days),
      activations: demo.bound ? 1 : 0,
      lastSeenAt: demo.bound ? new Date(Date.now() - index * 3600 * 1000).toISOString() : null,
      device: demo.bound
        ? {
            installationID: randomToken(16),
            model: demo.bound,
            systemVersion: demo.ios,
            systemBuild: demo.build,
            hwid: randomToken(8),
            publicKey: '',
            boundAt: new Date(Date.now() - (index + 2) * 36 * 3600 * 1000).toISOString(),
          }
        : null,
    };
    return entry;
  });
  store.write('keys', keys);

  store.write('packages', DEMO_PACKAGES.map((pkg) => ({
    id: randomToken(10),
    ...pkg,
    publishedAt: new Date().toISOString(),
  })));

  store.write('activity', [
    { type: 'activation.completed', licenseID: keys[0].id, device: 'iPhone15,3', at: new Date(Date.now() - 3600 * 1000).toISOString() },
    { type: 'permit.issued', licenseID: keys[0].id, package: 'com.dolomite.pkg.aim', action: 'apply', at: new Date(Date.now() - 2 * 3600 * 1000).toISOString() },
    { type: 'activation.started', licenseID: keys[2].id, device: 'iPhone16,2', at: new Date(Date.now() - 5 * 3600 * 1000).toISOString() },
    { type: 'activation.completed', licenseID: keys[3].id, device: 'iPhone14,2', at: new Date(Date.now() - 26 * 3600 * 1000).toISOString() },
  ]);

  store.write('notice', {
    enabled: true,
    message: 'Dolomite External 4.0 is live — new functions every week.',
    url: 'https://t.me/dolomiteexternal',
  });

  store.write('manifest', {
    product: 'dolomite-mod-vip',
    release_id: 'rel-2026-11',
    version: '4.0',
    name: 'Dolomite External 4.0',
    description: 'Initial function pack for Dolomite External.',
    required: false,
    packages: [],
  });

  store.write('games', [
    { name: 'Free Fire', bundleId: 'com.dts.freefireth', icon: '' },
    { name: 'Free Fire MAX', bundleId: 'com.dts.freefiremax', icon: '' },
    { name: 'PUBG Mobile', bundleId: 'com.tencent.ig', icon: '' },
  ]);

  console.log(`seeded ${keys.length} keys, ${DEMO_PACKAGES.length} packages`);
  for (const entry of keys) {
    console.log(`  ${entry.key}  ${entry.label}`);
  }
}

main();
